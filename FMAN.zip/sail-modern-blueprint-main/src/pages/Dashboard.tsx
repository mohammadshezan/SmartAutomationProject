import { MetricCard } from "@/components/MetricCard";
import { Button } from "@/components/ui/button";
import { 
  Activity, 
  TrendingUp, 
  Users, 
  Clock, 
  Package, 
  MapPin,
  AlertCircle,
  CheckCircle
} from "lucide-react";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard Overview</h1>
          <p className="text-muted-foreground">Monitor and manage steel plant logistics operations</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Activity className="w-4 h-4 mr-2" />
            Performance Report
          </Button>
          <Button className="gradient-primary shadow-primary">
            <MapPin className="w-4 h-4 mr-2" />
            Optimize Allocation
          </Button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Active Docks"
          value="12"
          subtitle="of 16 operational"
          icon={MapPin}
          variant="success"
          trend={{ value: "8%", isPositive: true }}
        />
        <MetricCard
          title="Avg Efficiency"
          value="91.5%"
          subtitle="Above 90% target"
          icon={TrendingUp}
          variant="success"
          trend={{ value: "2.3%", isPositive: true }}
        />
        <MetricCard
          title="Total Crew"
          value="86"
          subtitle="across all docks"
          icon={Users}
          variant="default"
        />
        <MetricCard
          title="Queue Length"
          value="8"
          subtitle="rakes waiting"
          icon={Clock}
          variant="warning"
          trend={{ value: "12%", isPositive: false }}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Loading Dock Alpha */}
        <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-slide-in-up">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold text-foreground">Loading Dock Alpha</h2>
              </div>
              <p className="text-sm text-muted-foreground">Mumbai Port Terminal</p>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-success text-success-foreground text-xs font-semibold uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
              Active
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Loading Rake R001</span>
                <span className="text-xs text-muted-foreground">ETA: 14:30</span>
              </div>
              <div className="w-full bg-background rounded-full h-2 mb-3">
                <div className="gradient-accent h-2 rounded-full" style={{ width: '70%' }}></div>
              </div>
              <p className="text-xs text-muted-foreground">2,800T / 4,000T (70% complete)</p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">8</span>
                </div>
                <p className="text-xs text-muted-foreground">Crew</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <TrendingUp className="w-4 h-4 text-success" />
                  <span className="text-2xl font-bold text-success">92%</span>
                </div>
                <p className="text-xs text-muted-foreground">Efficiency</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">2</span>
                </div>
                <p className="text-xs text-muted-foreground">Queue</p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1">Schedule</Button>
              <Button className="flex-1 gradient-accent">Manage</Button>
            </div>
          </div>
        </div>

        {/* Stockyard B Terminal */}
        <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold text-foreground">Stockyard B Terminal</h2>
              </div>
              <p className="text-sm text-muted-foreground">Delhi Distribution Hub</p>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-warning text-warning-foreground text-xs font-semibold uppercase">
              Idle
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-secondary rounded-lg p-6 text-center">
              <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="font-semibold text-foreground mb-1">Dock Available</p>
              <p className="text-sm text-muted-foreground">Ready for next assignment</p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">6</span>
                </div>
                <p className="text-xs text-muted-foreground">Crew</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <TrendingUp className="w-4 h-4 text-success" />
                  <span className="text-2xl font-bold text-success">87%</span>
                </div>
                <p className="text-xs text-muted-foreground">Efficiency</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">0</span>
                </div>
                <p className="text-xs text-muted-foreground">Queue</p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1">Schedule</Button>
              <Button className="flex-1 gradient-accent">Assign Rake</Button>
            </div>
          </div>
        </div>

        {/* Heavy Materials Dock */}
        <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold text-foreground">Heavy Materials Dock</h2>
              </div>
              <p className="text-sm text-muted-foreground">Chennai Steel Plant</p>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-destructive text-destructive-foreground text-xs font-semibold uppercase">
              Maintenance
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-destructive mb-1">Scheduled Maintenance</p>
                  <p className="text-sm text-muted-foreground">Equipment inspection in progress</p>
                  <p className="text-xs text-muted-foreground mt-2">Expected completion: 2 hours</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-muted-foreground">-</span>
                </div>
                <p className="text-xs text-muted-foreground">Crew</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-muted-foreground">-</span>
                </div>
                <p className="text-xs text-muted-foreground">Efficiency</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">3</span>
                </div>
                <p className="text-xs text-muted-foreground">Queue</p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" disabled>Schedule</Button>
              <Button className="flex-1" variant="outline" disabled>Manage</Button>
            </div>
          </div>
        </div>

        {/* Express Loading Bay */}
        <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-slide-in-up" style={{ animationDelay: '0.3s' }}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold text-foreground">Express Loading Bay</h2>
              </div>
              <p className="text-sm text-muted-foreground">Kolkata Terminal</p>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-success text-success-foreground text-xs font-semibold uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
              Active
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Loading Rake R003</span>
                <span className="text-xs text-muted-foreground">ETA: 13:45</span>
              </div>
              <div className="w-full bg-background rounded-full h-2 mb-3">
                <div className="gradient-accent h-2 rounded-full" style={{ width: '45%' }}></div>
              </div>
              <p className="text-xs text-muted-foreground">1,440T / 3,200T (45% complete)</p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">10</span>
                </div>
                <p className="text-xs text-muted-foreground">Crew</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <TrendingUp className="w-4 h-4 text-success" />
                  <span className="text-2xl font-bold text-success">95%</span>
                </div>
                <p className="text-xs text-muted-foreground">Efficiency</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-2xl font-bold text-foreground">1</span>
                </div>
                <p className="text-xs text-muted-foreground">Queue</p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1">Schedule</Button>
              <Button className="flex-1 gradient-accent">Manage</Button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-card">
        <h2 className="text-xl font-bold text-foreground mb-4">Recent Activities</h2>
        <div className="space-y-3">
          {[
            { time: "10 mins ago", message: "Rake R001 loading started at Dock Alpha", type: "success" },
            { time: "25 mins ago", message: "Stockyard B Terminal became available", type: "info" },
            { time: "1 hour ago", message: "Heavy Materials Dock entered maintenance mode", type: "warning" },
            { time: "2 hours ago", message: "Rake R003 assigned to Express Loading Bay", type: "success" },
          ].map((activity, idx) => (
            <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-secondary hover:bg-secondary/70 transition-base">
              {activity.type === "success" && <CheckCircle className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />}
              {activity.type === "warning" && <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />}
              {activity.type === "info" && <Activity className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />}
              <div className="flex-1">
                <p className="text-sm text-foreground">{activity.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
