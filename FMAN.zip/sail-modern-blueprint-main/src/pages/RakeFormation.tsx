import { MetricCard } from "@/components/MetricCard";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  Package, 
  AlertCircle, 
  Clock,
  MapPin,
  Zap
} from "lucide-react";

export default function RakeFormation() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">AI Rake Formation</h1>
          <p className="text-muted-foreground">Optimize rake composition and routing with AI recommendations</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Clock className="w-4 h-4 mr-2" />
            Schedule Analysis
          </Button>
          <Button className="gradient-primary shadow-primary">
            <Zap className="w-4 h-4 mr-2" />
            Run Optimization
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Pending Formations"
          value="12"
          icon={Package}
          variant="default"
        />
        <MetricCard
          title="Potential Savings"
          value="₹2.4M"
          icon={TrendingUp}
          variant="success"
          trend={{ value: "18%", isPositive: true }}
        />
        <MetricCard
          title="Avg Load Efficiency"
          value="94.2%"
          icon={TrendingUp}
          variant="success"
        />
        <MetricCard
          title="Critical Alerts"
          value="3"
          icon={AlertCircle}
          variant="danger"
        />
      </div>

      {/* AI Optimization Recommendations */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-card">
        <div className="flex items-center gap-2 mb-6">
          <Zap className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-bold text-foreground">AI Optimization Recommendations</h2>
        </div>

        <div className="space-y-4">
          {/* Recommendation 1 */}
          <div className="bg-gradient-to-r from-destructive/5 to-transparent border border-destructive/20 rounded-xl p-6 animate-slide-in-up">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3 flex-1">
                <StatusBadge status="high">High</StatusBadge>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">OPT001</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>Stockyard A → Mumbai Port</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Iron Ore</span>
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Coal</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Load Efficiency</p>
                <p className="text-3xl font-bold text-foreground">97%</p>
              </div>
            </div>
            
            <div className="bg-card rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">3400T / 3500T</span>
                <span className="text-sm font-semibold text-success">Savings: ₹45,000</span>
              </div>
              <div className="w-full bg-background rounded-full h-2.5">
                <div className="gradient-accent h-2.5 rounded-full" style={{ width: '97%' }}></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Time: 6 hours</p>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1">Details</Button>
              <Button className="flex-1 gradient-accent">Apply</Button>
            </div>
          </div>

          {/* Recommendation 2 */}
          <div className="bg-gradient-to-r from-warning/5 to-transparent border border-warning/20 rounded-xl p-6 animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3 flex-1">
                <StatusBadge status="medium">Medium</StatusBadge>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">OPT002</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>Stockyard B → Delhi Terminal</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Steel Coils</span>
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Billets</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Load Efficiency</p>
                <p className="text-3xl font-bold text-foreground">95%</p>
              </div>
            </div>
            
            <div className="bg-card rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">3800T / 4000T</span>
                <span className="text-sm font-semibold text-success">Savings: ₹32,000</span>
              </div>
              <div className="w-full bg-background rounded-full h-2.5">
                <div className="gradient-accent h-2.5 rounded-full" style={{ width: '95%' }}></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Time: 8 hours</p>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1">Details</Button>
              <Button className="flex-1 gradient-accent">Apply</Button>
            </div>
          </div>

          {/* Recommendation 3 */}
          <div className="bg-gradient-to-r from-success/5 to-transparent border border-success/20 rounded-xl p-6 animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3 flex-1">
                <StatusBadge status="low">Low</StatusBadge>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">OPT003</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>Stockyard C → Chennai Port</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Limestone</span>
                    <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">Iron Ore</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Load Efficiency</p>
                <p className="text-3xl font-bold text-foreground">100%</p>
              </div>
            </div>
            
            <div className="bg-card rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">3200T / 3200T</span>
                <span className="text-sm font-semibold text-success">Savings: ₹28,000</span>
              </div>
              <div className="w-full bg-background rounded-full h-2.5">
                <div className="gradient-success h-2.5 rounded-full" style={{ width: '100%' }}></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Time: 5 hours</p>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1">Details</Button>
              <Button className="flex-1 gradient-accent">Apply</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
