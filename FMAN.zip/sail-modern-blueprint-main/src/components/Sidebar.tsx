import { NavLink } from "react-router-dom";
import { 
  LayoutDashboard, 
  MapPin, 
  TrendingUp, 
  Package, 
  FileText, 
  BarChart3, 
  Users, 
  Settings,
  Activity
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Rake Formation", url: "/rake-formation", icon: TrendingUp },
  { title: "Material Inventory", url: "/inventory", icon: Package },
  { title: "Loading Points", url: "/loading-points", icon: MapPin },
  { title: "Orders", url: "/orders", icon: FileText },
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
  { title: "Personnel", url: "/personnel", icon: Users },
  { title: "Settings", url: "/settings", icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col shadow-md">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Activity className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">RakeOpt AI</h1>
            <p className="text-xs text-muted-foreground">Steel Logistics</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.title}
            to={item.url}
            end={item.url === "/"}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-base group",
                "hover:bg-sidebar-accent hover:shadow-sm",
                isActive
                  ? "bg-primary text-primary-foreground shadow-primary"
                  : "text-sidebar-foreground"
              )
            }
          >
            {({ isActive }) => (
              <>
                <item.icon className={cn("w-5 h-5", isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-primary")} />
                <span className="font-medium">{item.title}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Status Indicator */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="px-4 py-3 rounded-lg bg-success/10 border border-success/20">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-xs font-medium text-success-foreground">Real-time optimization active</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
