import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: "active" | "idle" | "maintenance" | "high" | "medium" | "low";
  children: React.ReactNode;
}

export function StatusBadge({ status, children }: StatusBadgeProps) {
  const statusStyles = {
    active: "bg-success text-success-foreground",
    idle: "bg-warning text-warning-foreground",
    maintenance: "bg-destructive text-destructive-foreground",
    high: "bg-destructive text-destructive-foreground",
    medium: "bg-warning text-warning-foreground",
    low: "bg-success text-success-foreground",
  };

  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide",
      statusStyles[status]
    )}>
      {(status === "active" || status === "low") && (
        <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
      )}
      {children}
    </span>
  );
}
