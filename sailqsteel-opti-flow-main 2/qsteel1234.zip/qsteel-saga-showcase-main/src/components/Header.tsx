import saqLogo from "@/assets/saq-logo.jpg";
import qsteelLogo from "@/assets/qsteel-logo.png";

const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-b border-border shadow-lg">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Parent Company - SAQ */}
          <div className="flex items-center gap-3 animate-fade-in">
            <img 
              src={saqLogo} 
              alt="SAIL - Steel Authority of India Limited" 
              className="h-12 md:h-16 w-auto object-contain"
            />
            <div className="hidden md:block border-l border-border pl-3">
              <p className="text-xs text-muted-foreground">Parent Company</p>
              <p className="text-sm font-semibold text-foreground">Steel Authority of India Limited</p>
            </div>
          </div>

          {/* Provider - QSteel */}
          <div className="flex items-center gap-3 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <div className="hidden md:block text-right border-r border-border pr-3">
              <p className="text-xs text-muted-foreground">Service Provider</p>
              <p className="text-sm font-semibold text-foreground">QSteel Solutions</p>
            </div>
            <img 
              src={qsteelLogo} 
              alt="QSteel - Quality Steel Solutions" 
              className="h-12 md:h-16 w-auto object-contain"
            />
          </div>
        </div>

        {/* Mobile view text */}
        <div className="md:hidden flex justify-between mt-2 text-xs text-muted-foreground">
          <span>Parent Company</span>
          <span>Service Provider</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
