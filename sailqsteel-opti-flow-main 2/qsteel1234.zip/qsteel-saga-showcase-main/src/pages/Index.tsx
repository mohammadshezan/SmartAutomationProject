import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import qatarBackground from "@/assets/qatar-background.jpg";
import statsBackground from "@/assets/stats-background.jpg";
import { ArrowRight, Factory, Train, Shield, TrendingUp, Users, Building2, Package, Globe, Award, Truck } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section with Train Background */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Fixed Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${qatarBackground})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/75 to-background/90" />
        
        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight">
              Powering India's
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mt-2">
                Steel Revolution
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
              Leading the nation with innovative steel solutions and logistics excellence. 
              A partnership built on strength, quality, and unwavering commitment.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all">
                <Users className="mr-2 h-5 w-5" />
                Customer Portal
              </Button>
              <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground shadow-lg hover:shadow-xl transition-all">
                <Building2 className="mr-2 h-5 w-5" />
                Employee Portal
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Our Core Strengths
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Delivering excellence across every aspect of steel manufacturing and logistics
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="group hover:shadow-xl transition-all duration-300 animate-fade-in hover:-translate-y-2 border-2"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="pt-6">
                  <div className="mb-4 inline-block p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section with Background */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${statsBackground})`,
          }}
        />
        <div className="absolute inset-0 bg-primary/75" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              Our Impact in Numbers
            </h2>
            <p className="text-white/90 text-lg">
              Delivering excellence across every metric
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {stats.map((stat, index) => (
              <div 
                key={index} 
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="mb-4 inline-flex items-center justify-center w-20 h-20 rounded-full border-4 border-white bg-white/10 backdrop-blur-sm">
                  <stat.icon className="h-10 w-10 text-white" strokeWidth={2} />
                </div>
                <div className="text-4xl md:text-5xl font-bold mb-2 text-white">
                  {stat.value}
                </div>
                <div className="text-white/90 text-sm md:text-base font-medium uppercase tracking-wide">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Information Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold text-foreground mb-4">Contact Us</h3>
              <p className="text-muted-foreground mb-2">Email: info@sailqsteel.com</p>
              <p className="text-muted-foreground mb-2">Phone: +91 1800 123 4567</p>
              <p className="text-muted-foreground">Fax: +91 1800 123 4568</p>
            </div>
            
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold text-foreground mb-4">Head Office</h3>
              <p className="text-muted-foreground mb-2">Steel Authority of India Limited</p>
              <p className="text-muted-foreground mb-2">Ispat Bhavan, Lodi Road</p>
              <p className="text-muted-foreground">New Delhi - 110003, India</p>
            </div>
            
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold text-foreground mb-4">Quick Links</h3>
              <div className="space-y-2">
                <p className="text-muted-foreground hover:text-primary cursor-pointer transition-colors">About Us</p>
                <p className="text-muted-foreground hover:text-primary cursor-pointer transition-colors">Products & Services</p>
                <p className="text-muted-foreground hover:text-primary cursor-pointer transition-colors">Careers</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container mx-auto px-4">
          <div className="text-center text-muted-foreground">
            <p className="text-sm">
              © 2024 SAIL & QSteel. Powering India's infrastructure with quality steel solutions.
            </p>
            <p className="text-xs mt-2">
              A partnership for excellence in steel manufacturing and logistics
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

const features = [
  {
    icon: Factory,
    title: "World-Class Manufacturing",
    description: "State-of-the-art facilities producing premium grade steel products"
  },
  {
    icon: Train,
    title: "Efficient Logistics",
    description: "Seamless rail and road transport network ensuring timely delivery"
  },
  {
    icon: Shield,
    title: "Quality Assurance",
    description: "Rigorous testing and certification for guaranteed quality standards"
  },
  {
    icon: TrendingUp,
    title: "Sustainable Growth",
    description: "Committed to environmental responsibility and continuous innovation"
  }
];

const stats = [
  { value: "50+", label: "Years of Excellence", icon: Award },
  { value: "20M+", label: "Tonnes Annually", icon: Package },
  { value: "1000+", label: "Expert Workforce", icon: Users },
  { value: "99%", label: "Client Satisfaction", icon: TrendingUp },
  { value: "15+", label: "Countries Served", icon: Globe },
  { value: "500+", label: "Daily Shipments", icon: Truck }
];

export default Index;
